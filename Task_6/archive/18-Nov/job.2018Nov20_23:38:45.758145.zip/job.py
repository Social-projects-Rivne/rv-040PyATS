from pyats import easypy

def main():
    easypy.run(testscript='test.py')